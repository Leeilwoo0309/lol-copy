var Projectile = /** @class */ (function () {
    function Projectile() {
        this.angle = 0;
        this.absPos = { x: 0, y: 0 };
        this.speed = 15;
        this._movedDistance = 0;
        this.isArrive = true;
        this.isSent = false;
        this.isCollide = false;
        this.damage = 0;
        this.critical = [0, 0];
        this.reach = -1;
        this.style = {
            color: 'orange'
        };
        this.ignoreObj = false;
        this.onhit = undefined;
    }
    Projectile.prototype.start = function (type) {
        var _this = this;
        var _main = document.querySelector('.projectiles');
        var _bullet = document.createElement('div');
        _bullet.className = "".concat(type, " bullet");
        _bullet.style.width = "".concat(this.size.width, "px");
        _bullet.style.height = "".concat(this.size.height, "px");
        _bullet.style.rotate = "".concat(-this.angle + Math.PI / 2, "rad");
        if (this.style.color !== undefined)
            _bullet.style.backgroundColor = "".concat(this.style.color);
        if (type === team) {
            _bullet.style.top = "".concat(-absolutePosition[team].y - cameraPosition.y + 4, "px");
            _bullet.style.left = "".concat(absolutePosition[team].x - cameraPosition.x + 4, "px");
            this.absPos.x = absolutePosition[team].x + 4;
            this.absPos.y = absolutePosition[team].y + 4;
        }
        else {
            _bullet.style.top = "".concat(-absolutePosition[getEnemyTeam()].y - cameraPosition.y + 4, "px");
            _bullet.style.left = "".concat(absolutePosition[getEnemyTeam()].x - cameraPosition.x + 4, "px");
            this.absPos.x = absolutePosition[getEnemyTeam()].x + 4;
            this.absPos.y = absolutePosition[getEnemyTeam()].y + 4;
        }
        if (this.damage == 0) {
            _bullet.style.opacity = "20%";
            _bullet.style.backgroundColor = "black";
        }
        _main.appendChild(_bullet);
        var update = setInterval(function () {
            var _a, _b;
            _this._movedDistance += _this.speed;
            _this.absPos.x += -_this.speed * Math.cos(_this.angle);
            _this.absPos.y += -_this.speed * Math.sin(_this.angle);
            _bullet.style.left = "".concat(_this.absPos.x - cameraPosition.x, "px");
            _bullet.style.top = "".concat(-_this.absPos.y - cameraPosition.y, "px");
            // on-hit
            if (type === getEnemyTeam()) {
                if (_this.isCollideWithPlayer(_bullet, team) && !_this.isCollide) {
                    var damageCoefficient_1 = (1 / (1 + players[team].spec.armor * 0.01));
                    _this.isCollide = true;
                    // 크리티컬 데미지
                    if (Math.random() <= _this.critical[0] / 100)
                        players[team].hp[1] -= _this.damage * (1.4 + _this.critical[1] / 100) * damageCoefficient_1;
                    else
                        players[team].hp[1] -= _this.damage * damageCoefficient_1;
                    // 아이템 감지
                    players[getEnemyTeam()].items.forEach(function (e) {
                        var _a;
                        if ((e === null || e === void 0 ? void 0 : e.name[1]) == '3_molwang' && !((_a = _this.onhit) === null || _a === void 0 ? void 0 : _a.includes('skill'))) {
                            players[team].hp[1] -= players[team].hp[1] * 0.06 * damageCoefficient_1;
                        }
                    });
                    if (((_a = players[team].marker) === null || _a === void 0 ? void 0 : _a.ezreal) == true) {
                        players[team].hp[1] -= (players[getEnemyTeam()].spec.ad * 1.2 + 5) * damageCoefficient_1;
                        players[team].marker.ezreal = false;
                    }
                    // 캐릭터별 온힛 효과
                    if (_this.onhit.includes("ezreal")) {
                        players[team].marker.ezreal = true;
                    }
                    socket.send(JSON.stringify({ body: { msg: "onhit", target: 'enemy' } }));
                }
                var nexusIndex = { blue: [7, 8], red: [9, 10] };
                if (_this.isCollideWithNexus(gameObjects[nexusIndex[team][1]].objSelector, _bullet) && gameObjects[nexusIndex[team][0]].isCollide(players[getEnemyTeam()].selector) && !_this.isCollide) {
                    nexusHp[team][1] -= _this.damage;
                    _this.isCollide = true;
                    socket.send(JSON.stringify({ body: { msg: 'onhit', target: 'nexus' } }));
                }
            }
            else {
                if (_this.isCollideWithPlayer(_bullet, getEnemyTeam()) && !_this.isCollide) {
                    if (char[team] == 'ezreal' && ((_b = _this.onhit) === null || _b === void 0 ? void 0 : _b.includes('skill'))) {
                        charClass.cooldown.q -= 100;
                        charClass.cooldown.e -= 100;
                        charClass.cooldown.shift -= 100;
                        charClass.cooldown.wheel -= 100;
                    }
                }
            }
            // 화면 밖으로 나가면 탄환 제거
            gameObjects.forEach(function (e) {
                if (_this.ignoreObj)
                    return false;
                if (e.isCollide(_bullet) && e.extra.canCollide && _this.isArrive) {
                    _this.isArrive = false;
                }
            });
            if (_this._movedDistance >= _this.reach * 1.5 && _this.isArrive) {
                _this.isArrive = false;
            }
            if (!_this.isArrive) {
                clearInterval(update);
                _main.removeChild(_bullet);
            }
        }, 16);
    };
    Projectile.prototype.isCollideWithPlayer = function (projectileSelector, team) {
        var r1 = players[team].selector.offsetWidth / 2;
        var r2 = projectileSelector.offsetWidth / 2;
        var x1 = players[team].selector.offsetLeft + r1;
        var y1 = players[team].selector.offsetTop + r1;
        var x2 = projectileSelector.offsetLeft + r2;
        var y2 = projectileSelector.offsetTop + r2;
        var distance = Math.sqrt(Math.pow((x2 - x1), 2) + Math.pow((y2 - y1), 2));
        return distance <= (r1 + r2);
    };
    Projectile.prototype.isCollideWithNexus = function (victim, projectileSelector) {
        var _a;
        if ((_a = this.onhit) === null || _a === void 0 ? void 0 : _a.includes('skill'))
            return false;
        var r1 = projectileSelector.offsetWidth / 2;
        var r2 = victim.offsetWidth / 2;
        var x1 = projectileSelector.offsetLeft + r1;
        var y1 = projectileSelector.offsetTop + r1;
        var x2 = victim.offsetLeft + r2;
        var y2 = victim.offsetTop + r2;
        var distance = Math.sqrt(Math.pow((x2 - x1), 2) + Math.pow((y2 - y1), 2));
        return distance <= (r1 + r2);
    };
    return Projectile;
}());
var ProjectileBuilder = /** @class */ (function () {
    function ProjectileBuilder() {
        this.projectile = new Projectile();
    }
    ProjectileBuilder.prototype.setDegree = function (degree) {
        this.projectile.angle = degree;
        return this;
    };
    ProjectileBuilder.prototype.setDamage = function (damage, random) {
        this.projectile.damage = damage;
        return this;
    };
    ProjectileBuilder.prototype.setSpeed = function (spd) {
        this.projectile.speed = spd;
        return this;
    };
    ProjectileBuilder.prototype.setPos = function (x, y) {
        this.projectile.absPos.x = x;
        this.projectile.absPos.y = y;
        return this;
    };
    ProjectileBuilder.prototype.setReach = function (time) {
        this.projectile.reach = time;
        return this;
    };
    ProjectileBuilder.prototype.setCritical = function (chance, damage) {
        this.projectile.critical = [chance, damage];
        return this;
    };
    ProjectileBuilder.prototype.setSize = function (size) {
        this.projectile.size = size;
        return this;
    };
    ProjectileBuilder.prototype.setStyle = function (color) {
        this.projectile.style.color = color;
        return this;
    };
    ProjectileBuilder.prototype.onHit = function (msg) {
        this.projectile.onhit = msg;
        return this;
    };
    ProjectileBuilder.prototype.ignoreObj = function (boolean) {
        if (boolean === void 0) { boolean = true; }
        this.projectile.ignoreObj = boolean;
        return this;
    };
    ProjectileBuilder.prototype.build = function (type) {
        this.projectile.start(type);
        return this.projectile;
    };
    return ProjectileBuilder;
}());
