var mathTeacher = new Char();
mathTeacher.skillQ = function () {
    console.log("Hi!");
};
