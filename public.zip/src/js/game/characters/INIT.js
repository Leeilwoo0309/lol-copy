var Char = /** @class */ (function () {
    function Char() {
        this.cooldown = {
            q: 0,
            e: 0,
            shift: 0,
            wheel: 0
        };
    }
    Char.prototype.passive = function () {
    };
    Char.prototype.skillQ = function () {
    };
    Char.prototype.skillE = function () {
    };
    Char.prototype.skillLShift = function () {
    };
    Char.prototype.skillWheel = function () {
    };
    Char.prototype.update = function () {
    };
    return Char;
}());
