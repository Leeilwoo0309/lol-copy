type KeyDown = {
    w: boolean,
    a: boolean,
    s: boolean,
    d: boolean,
    space: boolean,
    p: boolean,
    q: boolean,
    e: boolean,
    shift: boolean,
    // f: boolean,
    arrowup: boolean,
    arrowleft: boolean,
    arrowdown: boolean,
    arrowright: boolean,
    mouse: [boolean, boolean, boolean]
}

type Players = {
    blue: PlayerDeclare,
    red: PlayerDeclare,
}

type PlayerDeclare = {
    size: number,
    selector: HTMLDivElement,
    hp: [number, number],
    spec: Ability,
    specItem: Ability,
    specINIT: Ability,
    marker: Marker,
    gold: number,
    items: Item[],
}

type Marker = {
    ezreal?: boolean
}

type AbsolutePosition = {
    blue: {x: number, y: number},
    red: {x: number, y: number}
}

type ItemData = {
    cooldown: number,
    name: [string, string],
    price: number,
    ability: Ability,
    lower?: string[],
    extra?: number[],
    enable: boolean,
    des?: string,
    grade?: "시작" | "장화" | "기본" | "서사" | "전설",
};

type Ability = {
    range?: number,
    moveSpd?: number,
    ad?: number,
    ap?: number,
    atkspd?: number,
    projectileSpd?: number,
    health?: number,
    healthBoost?: number,
    armor?: number,
    vamp?: number,
    criticP?: number,
    criticD?: number,
    mana?: number,
    manaR?: number
}