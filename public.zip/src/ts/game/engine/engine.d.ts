type ObjSize = {
    width: number,
    height: number
}

type ObjPosition = {
    x: number,
    y: number
}