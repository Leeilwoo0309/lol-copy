game.style.cursor = 'pointer';
document.oncontextmenu = () => false;

gameObjects[8].objSelector.classList.add('ally');
gameObjects[10].objSelector.classList.add('enemy');
document.querySelector('.hp-bar.hp-progress').classList.add(team);

body.addEventListener('keydown', (e) => {
    if (keyDown[e.key.toLowerCase()] === false) {
        keyDown[e.key.toLowerCase()] = true;
    } else if (e.key == ' ') keyDown.space = true;
});

body.addEventListener('keyup', (e) => {
    if (keyDown[e.key.toLowerCase()] === true)
        keyDown[e.key.toLowerCase()] = false;
    else if (e.key == ' ') keyDown.space = false;
});

body.addEventListener('mousemove', e => {
    absolutePointerPosition.x = e.clientX + cameraPosition.x;
    absolutePointerPosition.y = -e.clientY - cameraPosition.y;

    // keyDown.arrowright = false;
    // keyDown.arrowdown = false;
    // keyDown.arrowleft = false;
    // keyDown.arrowup = false;

    // if (e.clientX < window.innerWidth * 0.1) keyDown.arrowleft = true;
    // if (e.clientX > window.innerWidth * 0.9) keyDown.arrowright = true;
    // if (e.clientY < window.innerHeight * 0.13) keyDown.arrowup = true;
    // if (e.clientY > window.innerHeight * 0.8) keyDown.arrowdown = true;
});

body.addEventListener('mousedown', (e) => {
    keyDown.mouse[e.button] = true;
});

body.addEventListener('mouseup', (e) => {
    keyDown.mouse[e.button] = false;
});

async function getCharInfo(char: string) {
    return await fetch(`http://kimchi-game.kro.kr:1973/getChar?char=${ char }`)
        .then(r => r.json())
        .then(result => result.body.defaultSpec);
}

async function getItemInfo() {
    return await fetch(`http://kimchi-game.kro.kr:1973/getItem`)
        .then(r => r.json())
        .then(result => result.body);
}

async function getData() {
    players[team].specINIT = await getCharInfo(char[team]);
    players[team].hp[0] = players[team].specINIT.health;
    players[team].hp[1] = players[team].specINIT.health;

    players[getEnemyTeam()].specINIT = await getCharInfo(char[getEnemyTeam()]);
    players[getEnemyTeam()].hp[0] = players[getEnemyTeam()].specINIT.health;
    players[getEnemyTeam()].hp[1] = players[getEnemyTeam()].specINIT.health;

    if (char[team] == 'ezreal') {
        charClass = ezreal;
    }

    let fetchedItemData: ItemData[] = await getItemInfo();
    itemData = [];
    fetchedItemData.forEach(e => {
        if (e.enable) {
            let item = new ItemBuilder()
                .setName(e.name[0], e.name[1]).setPrice(e.price)
                .setAbility(e.ability)
            
            if (e.lower) item.setLower(e.lower);
            if (e.grade) item.setGrade(e.grade);
            if (e.extra) item.setExtra(e.extra);
            if (e.des) item.setDescription(e.des);
    
            itemData.push(
                item.build()
            );
        }
    })
}