type Cooldown = {
    q: number,
    e: number
    shift: number,
    wheel: number
}

class Char {
    public cooldown: Cooldown = {
        q: 0,
        e: 0,
        shift: 0,
        wheel: 0
    };
    public cooldownINIT: Cooldown;

    public passive() {

    }

    public skillQ() {

    }

    public skillE() {

    }

    public skillLShift() {

    }

    public skillWheel() {

    }

    public update() {

    }
}