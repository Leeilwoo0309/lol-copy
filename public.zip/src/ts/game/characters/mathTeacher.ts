const mathTeacher = new Char();

mathTeacher.skillQ = () => {
    console.log("Hi!");
}